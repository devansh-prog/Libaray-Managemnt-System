
package l.m.s;
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Image;


public class Myimage extends Applet 
{
    Image picture;
    public void init()
    {
     picture = getImage(getDocumentBase(),"dev.jpeg");
    }
   
    public void paint(Graphics g)
    {
        g.drawImage(picture, 30,30, this);
    }
}
