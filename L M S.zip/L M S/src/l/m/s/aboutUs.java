/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l.m.s;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class aboutUs extends JFrame{

	private JPanel contentPane;

        public static void main(String[] args) {
            new aboutUs().setVisible(true);			
	}
    
        public aboutUs() {
            
            super("About Us");
            setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\ram\\Desktop\\rohit.jpg"));
            setBackground(new Color(173, 216, 230));
            setBounds(500, 250, 700, 500);
		
            contentPane = new JPanel();
            setContentPane(contentPane);
            contentPane.setLayout(null);

           
            JLabel l50 = new JLabel("New label");
            ImageIcon i50  = new ImageIcon(ClassLoader.getSystemResource("l/m/s/icons/logo.gif"));
            Image i40 = i50.getImage().getScaledInstance(200, 190,Image.SCALE_DEFAULT);
            ImageIcon i60 = new ImageIcon(i40);
            l50 = new JLabel(i60);
            l50.setBounds(0, 0, 200, 190);
            contentPane.add(l50);    
            JLabel l1 = new JLabel("New label");
            ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("l/m/s/icons/DEEKSHA1.jpeg"));
            Image i2 = i1.getImage().getScaledInstance(70, 70,Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            l1 = new JLabel(i3);
            l1.setBounds(550, 150, 70, 70);
            contentPane.add(l1);
            JLabel l80= new JLabel("New lable");
            ImageIcon ia  = new ImageIcon(ClassLoader.getSystemResource("l/m/s/icons/dev1.jpeg"));
            Image ib = ia.getImage().getScaledInstance(70, 70,Image.SCALE_DEFAULT);
            ImageIcon ic = new ImageIcon(ib);
            l80 = new JLabel(ic);
            l80.setBounds(550, 225, 70, 70);
            contentPane.add(l80);
             JLabel l90= new JLabel("New lable");
            ImageIcon ba  = new ImageIcon(ClassLoader.getSystemResource("l/m/s/icons/ayush.jpeg"));
            Image bb = ba.getImage().getScaledInstance(70, 70,Image.SCALE_DEFAULT);
            ImageIcon bc = new ImageIcon(bb);
            l90 = new JLabel(bc);
            l90.setBounds(550, 300, 70, 70);
            contentPane.add(l90);
            
            JLabel l100= new JLabel("New lable");
            ImageIcon ca  = new ImageIcon(ClassLoader.getSystemResource("l/m/s/icons/anjali.jpeg"));
            Image cb = ca.getImage().getScaledInstance(70, 70,Image.SCALE_DEFAULT);
            ImageIcon cc = new ImageIcon(cb);
            l100 = new JLabel(cc);
            l100.setBounds(550, 375, 70, 70);
            contentPane.add(l100);
            


          


            JLabel l6 = new JLabel("Developed By : GROUP 3");
            l6.setFont(new Font("Trebuchet MS", Font.BOLD, 30));
            l6.setBounds(225, 50, 600, 35);
            contentPane.add(l6);

            JLabel l7 = new JLabel("DEEKSHA SINGH:BCA 43 ROLL 201910101130086");
            l7.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
            l7.setBounds(70, 190, 600, 34);
            contentPane.add(l7);
            

            JLabel l8 = new JLabel("DEVANSH SAXENA:BCA 43 ROLL 201910101130081");
            l8.setFont(new Font("Trebuchet MS", Font.BOLD, 20));
            l8.setBounds(70, 265, 600, 34);
            contentPane.add(l8);

            JLabel l9 = new JLabel("AYUSH ARYA:BCA 43 ROLL 201910101130075");
            l9.setFont(new Font("Trebuchet MS", Font.BOLD , 20));
            l9.setBounds(70, 340, 600, 34);
            contentPane.add(l9);


            JLabel l10 = new JLabel("ANJALI GAUTAM:BCA 43 ROLL 201910101130063");
            l10.setForeground(new Color(47, 79, 79));
            l10.setFont(new Font("Trebuchet MS", Font.BOLD | Font.ITALIC, 20));
            l10.setBounds(70, 400, 600, 34);
            contentPane.add(l10);
                
                
            contentPane.setBackground(Color.WHITE);
	}
        

}


