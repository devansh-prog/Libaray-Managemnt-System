
package l.m.s;
    
import java.awt.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.*;
public class ReadMe  extends JFrame
{
     private JPanel contentPane;
    public static void main(String[] args)
    {
      new ReadMe().setVisible(false);  
    }
    public ReadMe(){
        JLabel l1;
  ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("l/m/s/icons/logo.gif"));
                Image i3 = i1.getImage().getScaledInstance(300, 300,Image.SCALE_DEFAULT);
                ImageIcon i2 = new ImageIcon(i3);
                l1 = new JLabel(i2);
                
		l1.setBounds(500, 175, 300, 300);
                contentPane = new JPanel();
            setContentPane(contentPane);
            contentPane.setLayout(null);
    
    JFrame frame = new JFrame("Read Me");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    String testStr = "The project titled Library Management System is Library Management software for monitoring and controlling the transactions in a library .The project “Library Management System” is developed in java, which mainly focuses on basic operations in a library like adding new books, and updating new information, searching books and members and return books.\n" +
"This project of “LIBRARY MANAGEMENT SYSTEM” of gives us the complete information about the library. We can enter the record of new books and retrieve the details of books available in the library. We can issue the books to the students and maintain their records and can also check how many books are issued and stock available in the library. \n" +
"Throughout the project the focus has been on presenting information and comments in an easy and intelligible manner. The project is very useful for those who want to know about Library Management System.";
    JTextArea wrapArea = new JTextArea(testStr, 25, 100);
    wrapArea.setFont(new Font("Trebuchet", Font.PLAIN, 16));
    wrapArea.setLineWrap(true);
    wrapArea.setWrapStyleWord(true);
    wrapArea.setCaretPosition(testStr.length());
    frame.add(new JScrollPane(wrapArea));
    frame.pack();
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
     wrapArea.add(l1);
    }    
}